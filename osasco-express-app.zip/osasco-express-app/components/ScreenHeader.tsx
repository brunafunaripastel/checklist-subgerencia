import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '../constants/Colors';

interface Props {
  tag: string;
  title: string;
  titleEm?: string;
  sub?: string;
  dark?: boolean;
}

export default function ScreenHeader({ tag, title, titleEm, sub, dark }: Props) {
  const router = useRouter();
  const bg = dark ? Colors.dark : Colors.bg;
  const titleColor = dark ? '#fff' : Colors.txt;
  const subColor = dark ? 'rgba(255,255,255,0.4)' : Colors.t2;
  const tagColor = dark ? Colors.red : Colors.red;
  const backColor = dark ? 'rgba(255,255,255,0.1)' : Colors.s1;
  const backTextColor = dark ? 'rgba(255,255,255,0.7)' : Colors.t2;

  return (
    <View style={[styles.header, { backgroundColor: bg }]}>
      <TouchableOpacity style={[styles.back, { backgroundColor: backColor }]} onPress={() => router.back()}>
        <Text style={[styles.backText, { color: backTextColor }]}>‹ Voltar</Text>
      </TouchableOpacity>
      <View style={styles.tagRow}>
        <View style={[styles.tagLine, { backgroundColor: tagColor }]} />
        <Text style={[styles.tag, { color: tagColor }]}>{tag}</Text>
      </View>
      <Text style={[styles.title, { color: titleColor }]}>
        {title}
        {titleEm ? <Text style={{ color: Colors.red }}> {titleEm}</Text> : null}
      </Text>
      {sub ? <Text style={[styles.sub, { color: subColor }]}>{sub}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  header: { paddingTop: 56, paddingHorizontal: 24, paddingBottom: 24 },
  back: {
    alignSelf: 'flex-start',
    borderRadius: 99,
    paddingHorizontal: 14,
    paddingVertical: 6,
    marginBottom: 20,
  },
  backText: { fontSize: 13, fontWeight: '600' },
  tagRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  tagLine: { width: 20, height: 2, borderRadius: 1 },
  tag: { fontSize: 10, fontWeight: '700', letterSpacing: 1.5, textTransform: 'uppercase' },
  title: { fontSize: 28, fontWeight: '900', letterSpacing: -0.4, lineHeight: 32, marginBottom: 8 },
  sub: { fontSize: 13, lineHeight: 20 },
});
