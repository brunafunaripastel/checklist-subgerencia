export const Colors = {
  red: '#ea1d2c',
  redDark: '#c0111e',
  redBg: '#fff5f5',
  redBorder: '#fcc',

  bg: '#f7f7f5',
  white: '#ffffff',
  s1: '#f2f1ee',
  s2: '#eae9e4',
  s3: '#dddcd6',
  s4: '#d4d4d0',

  txt: '#3e3e3e',
  t2: '#717171',
  t3: '#a0a0a0',
  t4: '#d4d4d0',

  grn: '#50a773',
  grnBg: '#f0faf4',
  grnBorder: '#b8dfc8',
  grnLight: '#4ade80',

  ora: '#ff7a00',
  oraBg: '#fff8f0',
  oraBorder: '#ffd4a8',

  blu: '#3483fa',
  bluBg: '#f0f5ff',
  bluBorder: '#c0d4fc',

  yel: '#f5a623',
  yelBg: '#fffbf0',

  dark: '#1a1a18',
  darkCard: 'rgba(255,255,255,0.05)',
  darkBorder: 'rgba(255,255,255,0.08)',
  darkText: 'rgba(255,255,255,0.4)',
  darkTextLight: 'rgba(255,255,255,0.25)',
};
