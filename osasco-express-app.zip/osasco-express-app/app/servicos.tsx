import { View, Text, StyleSheet, ScrollView } from 'react-native';
import ScreenHeader from '../components/ScreenHeader';
import { Colors } from '../constants/Colors';

const SERVICES = [
  {
    num: '01',
    icon: '🛵',
    title: 'Entregadores dedicados',
    desc: 'Equipe exclusiva Fratelli. Sem concorrência de outras operações durante o turno contratado.',
  },
  {
    num: '02',
    icon: '📱',
    title: 'Gerência de plataformas',
    desc: 'Operação ativa no iFood, 99Food e Cardápio Web. Aceitação de pedidos, pausas e suporte em tempo real.',
  },
  {
    num: '03',
    icon: '📊',
    title: 'Relatório semanal',
    desc: 'Toda segunda-feira: pedidos entregues, cancelamentos, receita e análise de desempenho.',
  },
  {
    num: '04',
    icon: '⚡',
    title: 'Resposta rápida',
    desc: 'Substituição de entregador em até 30 min em caso de imprevisto. Canal WhatsApp direto 24h.',
  },
  {
    num: '05',
    icon: '🔧',
    title: 'Integração técnica',
    desc: 'Setup inicial no Foody Delivery, configuração de rotas e integração com todas as plataformas.',
  },
  {
    num: '06',
    icon: '🏷️',
    title: 'Identidade visual',
    desc: 'Entregadores com fardamento adequado à identidade do Fratelli. Apresentação profissional garantida.',
  },
];

const PAIN = [
  { icon: '❌', title: 'Taxa de cancelamento', val: '17,9%', desc: '85 pedidos perdidos · R$ 1.700 / mês jogados fora', ok: false },
  { icon: '✅', title: 'Com Osasco Express', val: '<5%', desc: 'Entregador próprio = controle total da última milha', ok: true },
];

export default function ServicosScreen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.bg }} showsVerticalScrollIndicator={false}>
      <ScreenHeader
        tag="O que entregamos"
        title="Sua logística,"
        titleEm="nossa responsabilidade."
        sub="Seis pilares que eliminam cancelamentos e aumentam sua receita."
      />

      {/* Pain vs Solução */}
      <View style={styles.painRow}>
        {PAIN.map((p, i) => (
          <View key={i} style={[styles.painCard, p.ok && styles.painCardOk]}>
            <Text style={styles.painIcon}>{p.icon}</Text>
            <Text style={styles.painTitle}>{p.title}</Text>
            <Text style={[styles.painVal, p.ok && { color: Colors.grn }]}>{p.val}</Text>
            <Text style={styles.painDesc}>{p.desc}</Text>
          </View>
        ))}
      </View>

      {/* Serviços */}
      <View style={styles.servicesGrid}>
        {SERVICES.map((s) => (
          <View key={s.num} style={styles.serviceCard}>
            <Text style={styles.serviceNum}>{s.num}</Text>
            <Text style={styles.serviceIcon}>{s.icon}</Text>
            <Text style={styles.serviceTitle}>{s.title}</Text>
            <Text style={styles.serviceDesc}>{s.desc}</Text>
          </View>
        ))}
      </View>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  painRow: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  painCard: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.s3,
    padding: 18,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 4,
    elevation: 2,
  },
  painCardOk: { borderColor: Colors.grnBorder, backgroundColor: Colors.grnBg },
  painIcon: { fontSize: 24, marginBottom: 10 },
  painTitle: { fontSize: 12, fontWeight: '800', color: Colors.txt, marginBottom: 4 },
  painVal: {
    fontFamily: 'monospace',
    fontSize: 28,
    fontWeight: '600',
    color: Colors.red,
    marginBottom: 4,
  },
  painDesc: { fontSize: 11, color: Colors.t2, lineHeight: 16 },

  servicesGrid: {
    paddingHorizontal: 20,
    gap: 12,
  },
  serviceCard: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.s3,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 4,
    elevation: 2,
  },
  serviceNum: {
    fontFamily: 'monospace',
    fontSize: 10,
    fontWeight: '600',
    color: Colors.t3,
    marginBottom: 8,
  },
  serviceIcon: { fontSize: 22, marginBottom: 8 },
  serviceTitle: { fontSize: 14, fontWeight: '800', color: Colors.txt, marginBottom: 6 },
  serviceDesc: { fontSize: 12, color: Colors.t2, lineHeight: 18 },
});
