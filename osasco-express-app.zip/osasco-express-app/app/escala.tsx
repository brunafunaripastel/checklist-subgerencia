import { View, Text, StyleSheet, ScrollView } from 'react-native';
import ScreenHeader from '../components/ScreenHeader';
import { Colors } from '../constants/Colors';

export default function EscalaScreen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.bg }} showsVerticalScrollIndicator={false}>
      <ScreenHeader
        tag="Escala operacional"
        title="Entregadores certos"
        titleEm="no horário certo."
        sub="Baseado nos seus picos reais: 17h é o horário crítico, Sexta é o dia mais movido."
      />

      {/* Seg–Qui */}
      <View style={styles.escalaCard}>
        <View style={styles.escalaHeader}>
          <Text style={styles.escalaTitle}>Segunda → Quinta</Text>
          <View style={[styles.badge, styles.badgeUtil]}>
            <Text style={[styles.badgeText, { color: Colors.blu }]}>Dias úteis</Text>
          </View>
        </View>
        <View style={styles.bubbles}>
          {[1,2,3,4].map(i => (
            <View key={i} style={[styles.bubble, styles.bubbleActive]}>
              <Text style={{ fontSize: 18 }}>🛵</Text>
            </View>
          ))}
        </View>
        <View style={styles.infoBox}>
          <InfoRow icon="👥" label="Equipe" val="4 entregadores" />
          <InfoRow icon="🕔" label="Turno" val="17h às 23h30" />
          <InfoRow icon="💰" label="Custo/dia" val="4 × R$70 = R$280" />
          <InfoRow icon="📊" label="Pico" val="17h — 84 pedidos cobertos" />
          <InfoRow icon="⏰" label="Hora extra" val="R$10/entregador" />
        </View>
      </View>

      {/* Sex–Dom */}
      <View style={[styles.escalaCard, styles.escalaCardFds]}>
        <View style={styles.escalaHeader}>
          <Text style={styles.escalaTitle}>Sexta → Domingo</Text>
          <View style={[styles.badge, styles.badgeFds]}>
            <Text style={[styles.badgeText, { color: Colors.red }]}>Final de semana</Text>
          </View>
        </View>
        <View style={styles.bubbles}>
          {[1,2,3,4,5,6,7].map(i => (
            <View key={i} style={[styles.bubble, styles.bubbleActiveFds]}>
              <Text style={{ fontSize: 18 }}>🛵</Text>
            </View>
          ))}
        </View>
        <View style={styles.infoBox}>
          <InfoRow icon="👥" label="Equipe" val="7 entregadores" />
          <InfoRow icon="🕔" label="Turno" val="17h às 23h30" />
          <InfoRow icon="💰" label="Custo/dia" val="7 × R$70 = R$490" />
          <InfoRow icon="🔥" label="Sexta" val="107 pedidos — equipe reforçada" />
          <InfoRow icon="🎉" label="Feriados" val="R$80/entregador" />
        </View>
      </View>

      {/* Summary */}
      <View style={styles.summary}>
        <Text style={styles.summaryTitle}>💡 Resumo semanal estimado</Text>
        <View style={styles.summaryGrid}>
          <SummaryBox label="Seg–Qui (4 dias)" val="R$1.120" />
          <SummaryBox label="Sex–Dom (3 dias)" val="R$1.470" />
          <SummaryBox label="Total / semana" val="~R$2.590" highlight />
        </View>
      </View>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const InfoRow = ({ icon, label, val }: any) => (
  <View style={styles.infoRow}>
    <Text style={styles.infoIcon}>{icon}</Text>
    <Text style={styles.infoLabel}>{label}</Text>
    <Text style={styles.infoVal}>{val}</Text>
  </View>
);

const SummaryBox = ({ label, val, highlight }: any) => (
  <View style={[styles.summaryBox, highlight && styles.summaryBoxHi]}>
    <Text style={[styles.summaryBoxLabel, highlight && { color: '#fff' }]}>{label}</Text>
    <Text style={[styles.summaryBoxVal, highlight && { color: '#fff' }]}>{val}</Text>
  </View>
);

const styles = StyleSheet.create({
  escalaCard: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.s3,
    padding: 20,
    marginHorizontal: 20,
    marginBottom: 14,
  },
  escalaCardFds: { borderColor: Colors.redBorder, backgroundColor: Colors.redBg },
  escalaHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  escalaTitle: { fontSize: 15, fontWeight: '800', color: Colors.txt },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 99, borderWidth: 1 },
  badgeUtil: { backgroundColor: Colors.bluBg, borderColor: Colors.bluBorder },
  badgeFds: { backgroundColor: Colors.redBg, borderColor: Colors.redBorder },
  badgeText: { fontSize: 10, fontWeight: '700' },
  bubbles: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 14 },
  bubble: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.s1,
    borderWidth: 1.5, borderColor: Colors.s3,
    alignItems: 'center', justifyContent: 'center',
  },
  bubbleActive: { backgroundColor: Colors.bluBg, borderColor: Colors.bluBorder },
  bubbleActiveFds: { backgroundColor: Colors.redBg, borderColor: Colors.redBorder },
  infoBox: { gap: 6 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  infoIcon: { fontSize: 13, width: 20 },
  infoLabel: { fontSize: 11, color: Colors.t2, width: 80 },
  infoVal: { fontSize: 12, fontWeight: '600', color: Colors.txt, flex: 1 },

  summary: { marginHorizontal: 20, marginBottom: 14 },
  summaryTitle: { fontSize: 13, fontWeight: '700', color: Colors.txt, marginBottom: 10 },
  summaryGrid: { flexDirection: 'row', gap: 8 },
  summaryBox: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: Colors.s3,
    padding: 12,
    alignItems: 'center',
  },
  summaryBoxHi: { backgroundColor: Colors.red, borderColor: Colors.red },
  summaryBoxLabel: { fontSize: 9, color: Colors.t2, textAlign: 'center', marginBottom: 4 },
  summaryBoxVal: { fontFamily: 'monospace', fontSize: 15, fontWeight: '700', color: Colors.txt },
});
