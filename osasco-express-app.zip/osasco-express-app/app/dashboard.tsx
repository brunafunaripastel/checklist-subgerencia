import { View, Text, StyleSheet, ScrollView } from 'react-native';
import ScreenHeader from '../components/ScreenHeader';
import { Colors } from '../constants/Colors';

const KpiCard = ({ label, val, color, src }: any) => (
  <View style={[styles.kpiCard, { borderTopColor: color }]}>
    <Text style={styles.kpiLbl}>{label}</Text>
    <Text style={[styles.kpiVal, { color }]}>{val}</Text>
    {src ? <Text style={styles.kpiSrc}>{src}</Text> : null}
  </View>
);

const BarChart = ({ data, labels, title }: any) => {
  const max = Math.max(...data);
  return (
    <View style={styles.chartCard}>
      <Text style={styles.chartLabel}>{title}</Text>
      <View style={styles.bars}>
        {data.map((v: number, i: number) => (
          <View key={i} style={styles.barCol}>
            <View style={[
              styles.bar,
              {
                height: (v / max) * 80,
                backgroundColor: v === max ? Colors.red : 'rgba(255,255,255,0.15)',
              }
            ]} />
            <Text style={styles.barLabel}>{labels[i]}</Text>
          </View>
        ))}
      </View>
    </View>
  );
};

const DonutSimple = ({ a, b, aLabel, bLabel, title }: any) => {
  const total = a + b;
  const pctA = Math.round((a / total) * 100);
  return (
    <View style={styles.chartCard}>
      <Text style={styles.chartLabel}>{title}</Text>
      <View style={styles.donutWrap}>
        <View style={styles.donutCircle}>
          <Text style={styles.donutPct}>{pctA}%</Text>
          <Text style={styles.donutSub}>{aLabel.split(' ')[0]}</Text>
        </View>
      </View>
      <View style={styles.legend}>
        <View style={styles.legendRow}>
          <View style={[styles.legendDot, { backgroundColor: Colors.grnLight }]} />
          <Text style={styles.legendTxt}>{aLabel} ({a})</Text>
        </View>
        <View style={styles.legendRow}>
          <View style={[styles.legendDot, { backgroundColor: '#f87171' }]} />
          <Text style={styles.legendTxt}>{bLabel} ({b})</Text>
        </View>
      </View>
    </View>
  );
};

export default function DashboardScreen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.dark }} showsVerticalScrollIndicator={false}>
      <ScreenHeader
        dark
        tag="Dados reais · Outubro/2024"
        title="Dashboard"
        titleEm="Fratelli"
        sub="Baseado nos dados reais da operação do restaurante."
      />

      {/* KPIs */}
      <View style={styles.kpiRow}>
        <KpiCard label="PEDIDOS / MÊS" val="474" color={Colors.red} src="iFood + 99Food" />
        <KpiCard label="TAXA CANCEL." val="17,9%" color="#fb923c" />
      </View>
      <View style={styles.kpiRow}>
        <KpiCard label="RECEITA BRUTA" val="~R$14k" color={Colors.grnLight} src="estimado" />
        <KpiCard label="PEDIDOS PERDIDOS" val="85" color="#fbbf24" />
      </View>

      {/* Gráfico Hora */}
      <BarChart
        title="PEDIDOS POR HORA"
        data={[23, 27, 26, 23, 30, 36, 84, 69, 51, 50, 29, 26]}
        labels={['11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22']}
      />

      {/* Gráfico Dia */}
      <BarChart
        title="PEDIDOS POR DIA DA SEMANA"
        data={[15, 9, 80, 95, 107, 90, 78]}
        labels={['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom']}
      />

      {/* Donuts */}
      <View style={styles.donutRow}>
        <View style={{ flex: 1 }}>
          <DonutSimple a={389} b={85} aLabel="Concluídos" bLabel="Cancelados" title="STATUS DOS PEDIDOS" />
        </View>
        <View style={{ flex: 1 }}>
          <DonutSimple a={442} b={32} aLabel="Online" bLabel="Dinheiro" title="FORMA DE PAGAMENTO" />
        </View>
      </View>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  kpiRow: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  kpiCard: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.07)',
    borderTopWidth: 3,
    padding: 14,
  },
  kpiLbl: {
    fontSize: 9,
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: 'rgba(255,255,255,0.3)',
    fontWeight: '700',
    marginBottom: 6,
  },
  kpiVal: {
    fontFamily: 'monospace',
    fontSize: 20,
    fontWeight: '600',
    color: '#fff',
  },
  kpiSrc: { fontSize: 9, color: 'rgba(255,255,255,0.2)', marginTop: 3 },

  chartCard: {
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.07)',
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 10,
  },
  chartLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: 'rgba(255,255,255,0.4)',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
    marginBottom: 12,
  },
  bars: { flexDirection: 'row', alignItems: 'flex-end', height: 90, gap: 4 },
  barCol: { flex: 1, alignItems: 'center', justifyContent: 'flex-end' },
  bar: { width: '100%', borderRadius: 3, minHeight: 4 },
  barLabel: { fontSize: 8, color: 'rgba(255,255,255,0.3)', marginTop: 4 },

  donutRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 20, marginBottom: 10 },
  donutWrap: { alignItems: 'center', marginVertical: 12 },
  donutCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 10,
    borderColor: Colors.grnLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  donutPct: { fontSize: 14, fontWeight: '700', color: '#fff' },
  donutSub: { fontSize: 8, color: 'rgba(255,255,255,0.4)' },
  legend: { gap: 4 },
  legendRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendTxt: { fontSize: 9, color: 'rgba(255,255,255,0.4)' },
});
