import { View, Text, StyleSheet, ScrollView } from 'react-native';
import ScreenHeader from '../components/ScreenHeader';
import { Colors } from '../constants/Colors';

const ROI_ITEMS = [
  { icon: '📦', label: 'Pedidos cancelados / mês', val: '85 pedidos', color: '#f87171' },
  { icon: '💸', label: 'Receita perdida estimada', val: '~R$ 1.700/mês', color: '#f87171' },
  { icon: '💰', label: 'Custo Osasco Express (sem/dom)', val: '~R$ 2.590/sem', color: '#fff' },
  { icon: '📈', label: 'Redução de cancelamentos', val: 'até 80%', color: Colors.grnLight },
  { icon: '🎯', label: 'Receita recuperada estimada', val: '+R$ 1.360/mês', color: Colors.grnLight },
];

const SUMMARY_LINES = [
  { label: 'Cancelamentos atuais / mês', val: '17,9% (85 pedidos)', color: '#f87171' },
  { label: 'Perda por cancelamento', val: '~R$ 1.700', color: '#f87171' },
  { label: 'Investimento mensal', val: '~R$ 10.360', color: '#fff' },
  { label: 'Receita recuperada (80%)', val: '+R$ 1.360', color: Colors.grnLight },
  { label: 'Cancelamentos alvo', val: '< 5%', color: Colors.grnLight },
];

export default function RoiScreen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.dark }} showsVerticalScrollIndicator={false}>
      <ScreenHeader
        dark
        tag="Retorno do investimento"
        title="O número que"
        titleEm="importa."
        sub="Quanto você perde hoje vs quanto o Osasco Express custa."
      />

      {/* ROI Items */}
      <View style={styles.section}>
        {ROI_ITEMS.map((item, i) => (
          <View key={i} style={styles.roiItem}>
            <Text style={styles.roiIcon}>{item.icon}</Text>
            <View style={styles.roiTexts}>
              <Text style={styles.roiItemLabel}>{item.label}</Text>
              <Text style={[styles.roiItemVal, { color: item.color }]}>{item.val}</Text>
            </View>
          </View>
        ))}
      </View>

      {/* Summary card */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>RESUMO FINANCEIRO</Text>
        {SUMMARY_LINES.map((line, i) => (
          <View key={i} style={[styles.summaryLine, i === SUMMARY_LINES.length - 1 && { borderBottomWidth: 0 }]}>
            <Text style={styles.summaryLabel}>{line.label}</Text>
            <Text style={[styles.summaryVal, { color: line.color }]}>{line.val}</Text>
          </View>
        ))}
        <View style={styles.totalBox}>
          <Text style={styles.totalLabel}>RECUPERAÇÃO LÍQUIDA ESTIMADA</Text>
          <Text style={styles.totalVal}>+R$ 1.360/mês</Text>
          <Text style={styles.totalSub}>apenas pela redução de cancelamentos</Text>
        </View>
      </View>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  section: { paddingHorizontal: 20, gap: 10, marginBottom: 16 },
  roiItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  roiIcon: { fontSize: 18 },
  roiTexts: { flex: 1 },
  roiItemLabel: { fontSize: 11, color: 'rgba(255,255,255,0.4)', marginBottom: 2 },
  roiItemVal: { fontFamily: 'monospace', fontSize: 15, fontWeight: '600', color: '#fff' },

  summaryCard: {
    marginHorizontal: 20,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    padding: 24,
  },
  summaryTitle: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: 'rgba(255,255,255,0.35)',
    marginBottom: 18,
  },
  summaryLine: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.06)',
  },
  summaryLabel: { fontSize: 12, color: 'rgba(255,255,255,0.45)', flex: 1 },
  summaryVal: { fontFamily: 'monospace', fontSize: 12, fontWeight: '600', color: '#fff' },

  totalBox: {
    marginTop: 18,
    padding: 18,
    backgroundColor: 'rgba(74,222,128,0.07)',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(74,222,128,0.18)',
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: 'rgba(255,255,255,0.3)',
    marginBottom: 6,
    textAlign: 'center',
  },
  totalVal: { fontSize: 28, fontWeight: '900', color: Colors.grnLight },
  totalSub: { fontSize: 10, color: 'rgba(255,255,255,0.25)', marginTop: 4 },
});
