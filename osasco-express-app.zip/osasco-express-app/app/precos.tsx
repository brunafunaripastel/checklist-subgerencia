import { View, Text, StyleSheet, ScrollView } from 'react-native';
import ScreenHeader from '../components/ScreenHeader';
import { Colors } from '../constants/Colors';

const SEG_QUI = [
  { dist: 'Até 0,5 km', val: 'R$ 6,00', hi: false },
  { dist: '1 km a 2 km', val: 'R$ 8,00', hi: false },
  { dist: '3 km a 4 km', val: 'R$ 8,00', hi: false },
  { dist: '5 km a 6 km', val: 'R$ 10,00', hi: true },
  { dist: 'Acima de 6 km', val: '+R$1,50/km', hi: false },
];

const SEX_DOM = [
  { dist: 'Até 0,5 km', val: 'R$ 6,00', hi: false },
  { dist: '1 km a 3 km', val: 'R$ 9,00', hi: false },
  { dist: '4 km a 6 km', val: 'R$ 12,00', hi: true },
  { dist: 'Acima de 6 km', val: '+R$1,50/km', hi: false },
];

const EXTRAS = [
  { icon: '🌧️', title: 'Dias de chuva', val: '+50%', desc: 'Sobre o valor da entrega' },
  { icon: '⏱️', title: 'Hora extra', val: 'R$ 10,00', desc: 'Por entregador após 23h30' },
  { icon: '➕', title: 'Entregador adicional', val: 'R$ 70,00', desc: 'Por turno, sob solicitação' },
  { icon: '🔄', title: 'Flexível (apoio)', val: 'R$30/dia', desc: '+ taxas · mín 2 entregas' },
  { icon: '💳', title: 'Maquininha (retorno)', val: 'R$ 2,50', desc: 'Por entrega com cartão' },
  { icon: '📄', title: 'Nota fiscal', val: '+5%', desc: 'Sob solicitação · semanal' },
];

const KmRow = ({ dist, val, hi }: any) => (
  <View style={[styles.kmRow, hi && styles.kmRowHi]}>
    <Text style={styles.kmDist}>{dist}</Text>
    <Text style={[styles.kmVal, hi && styles.kmValHi]}>{val}</Text>
  </View>
);

export default function PrecosScreen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.bg }} showsVerticalScrollIndicator={false}>
      <ScreenHeader
        tag="Tabela de valores"
        title="Preços transparentes."
        titleEm="Sem surpresas."
      />

      {/* Hero price */}
      <View style={styles.priceHero}>
        <View>
          <Text style={styles.priceHeroTag}>DIÁRIA POR ENTREGADOR</Text>
          <Text style={styles.priceHeroTitle}>R$70,00 / turno de 7h</Text>
          <Text style={styles.priceHeroSub}>Dias regulares · Feriados: R$80,00</Text>
        </View>
        <View style={styles.priceStats}>
          <View style={styles.priceStat}>
            <Text style={styles.priceStatVal}>R$280</Text>
            <Text style={styles.priceStatLabel}>Seg–Qui/dia</Text>
          </View>
          <View style={styles.priceStat}>
            <Text style={styles.priceStatVal}>R$490</Text>
            <Text style={styles.priceStatLabel}>Sex–Dom/dia</Text>
          </View>
        </View>
      </View>

      {/* Tables */}
      <View style={styles.tables}>
        <View style={styles.tableCard}>
          <View style={[styles.tableHead, styles.tableHeadSeg]}>
            <Text style={styles.tableHeadTextSeg}>📅 Segunda a Quinta</Text>
          </View>
          <View style={styles.tableBody}>
            {SEG_QUI.map((row, i) => <KmRow key={i} {...row} />)}
          </View>
        </View>

        <View style={styles.tableCard}>
          <View style={[styles.tableHead, styles.tableHeadFds]}>
            <Text style={styles.tableHeadTextFds}>🔥 Sexta a Domingo</Text>
          </View>
          <View style={styles.tableBody}>
            {SEX_DOM.map((row, i) => <KmRow key={i} {...row} />)}
          </View>
        </View>
      </View>

      {/* Extras */}
      <Text style={styles.extrasTitle}>Adicionais</Text>
      <View style={styles.extrasGrid}>
        {EXTRAS.map((e, i) => (
          <View key={i} style={styles.extraCard}>
            <Text style={styles.extraIcon}>{e.icon}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.extraTitle}>{e.title}</Text>
              <Text style={styles.extraVal}>{e.val}</Text>
              <Text style={styles.extraDesc}>{e.desc}</Text>
            </View>
          </View>
        ))}
      </View>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  priceHero: {
    backgroundColor: Colors.red,
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  priceHeroTag: { fontSize: 9, color: 'rgba(255,255,255,0.65)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 },
  priceHeroTitle: { fontSize: 17, fontWeight: '900', color: '#fff', marginBottom: 2 },
  priceHeroSub: { fontSize: 11, color: 'rgba(255,255,255,0.65)' },
  priceStats: { gap: 8 },
  priceStat: { alignItems: 'flex-end' },
  priceStatVal: { fontFamily: 'monospace', fontSize: 18, fontWeight: '600', color: '#fff' },
  priceStatLabel: { fontSize: 9, color: 'rgba(255,255,255,0.55)', textTransform: 'uppercase' },

  tables: { paddingHorizontal: 20, gap: 12, marginBottom: 20 },
  tableCard: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.s3,
    overflow: 'hidden',
  },
  tableHead: { padding: 12, paddingHorizontal: 16 },
  tableHeadSeg: { backgroundColor: Colors.s1, borderBottomWidth: 1, borderBottomColor: Colors.s2 },
  tableHeadFds: { backgroundColor: Colors.red },
  tableHeadTextSeg: { fontSize: 12, fontWeight: '800', color: Colors.txt },
  tableHeadTextFds: { fontSize: 12, fontWeight: '800', color: '#fff' },
  tableBody: { padding: 10 },
  kmRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 8,
    paddingHorizontal: 10,
    borderRadius: 8,
    marginBottom: 3,
  },
  kmRowHi: { backgroundColor: Colors.redBg },
  kmDist: { fontSize: 12, color: Colors.t2 },
  kmVal: { fontFamily: 'monospace', fontSize: 12, fontWeight: '600', color: Colors.txt },
  kmValHi: { color: Colors.red, fontSize: 14 },

  extrasTitle: { fontSize: 12, fontWeight: '700', color: Colors.t3, letterSpacing: 1, textTransform: 'uppercase', paddingHorizontal: 20, marginBottom: 12 },
  extrasGrid: { paddingHorizontal: 20, gap: 10 },
  extraCard: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: Colors.white,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: Colors.s3,
    padding: 14,
  },
  extraIcon: { fontSize: 18 },
  extraTitle: { fontSize: 11, fontWeight: '800', color: Colors.txt, marginBottom: 2 },
  extraVal: { fontFamily: 'monospace', fontSize: 14, fontWeight: '600', color: Colors.red, marginBottom: 2 },
  extraDesc: { fontSize: 10, color: Colors.t3 },
});
