import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';

export default function RootLayout() {
  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: '#f7f7f5' },
          animation: 'slide_from_right',
        }}
      >
        <Stack.Screen name="index" />
        <Stack.Screen name="dashboard" />
        <Stack.Screen name="servicos" />
        <Stack.Screen name="roi" />
        <Stack.Screen name="precos" />
        <Stack.Screen name="escala" />
        <Stack.Screen name="contrato" />
        <Stack.Screen name="proximos-passos" />
      </Stack>
    </>
  );
}
