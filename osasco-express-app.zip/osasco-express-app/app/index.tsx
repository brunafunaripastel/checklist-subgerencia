import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Linking, Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '../constants/Colors';

const { width } = Dimensions.get('window');

const KPI = ({ val, label, color }: { val: string; label: string; color?: string }) => (
  <View style={styles.kpiBox}>
    <Text style={[styles.kpiVal, color ? { color } : {}]}>{val}</Text>
    <Text style={styles.kpiLabel}>{label}</Text>
  </View>
);

const MENU = [
  { label: '📊 Dashboard', route: '/dashboard', desc: 'Dados reais do Fratelli' },
  { label: '🛵 Serviços', route: '/servicos', desc: 'O que entregamos' },
  { label: '💰 ROI', route: '/roi', desc: 'Retorno do investimento' },
  { label: '📋 Preços', route: '/precos', desc: 'Tabela de valores' },
  { label: '📅 Escala', route: '/escala', desc: 'Operacional detalhado' },
  { label: '📄 Contrato', route: '/contrato', desc: 'Termos e cláusulas' },
  { label: '🚀 Próximos Passos', route: '/proximos-passos', desc: 'Como começar' },
];

export default function HomeScreen() {
  const router = useRouter();

  return (
    <ScrollView style={styles.screen} showsVerticalScrollIndicator={false}>
      {/* HERO */}
      <View style={styles.hero}>
        <View style={styles.heroBadge}>
          <View style={styles.badgeDot} />
          <Text style={styles.badgeText}>PROPOSTA COMERCIAL 2026</Text>
        </View>

        <Text style={styles.heroTitle}>
          Osasco Express{'\n'}
          <Text style={styles.heroTitleRed}>× Fratelli</Text>
        </Text>
        <Text style={styles.heroSub}>
          Logística própria. Menos cancelamentos. Mais lucro.
          Dados reais, proposta clara.
        </Text>

        {/* KPIs */}
        <View style={styles.kpiGrid}>
          <KPI val="474" label="PEDIDOS / MÊS" />
          <KPI val="17,9%" label="CANCELADOS" color="#ff6b6b" />
          <KPI val="R$14k" label="RECEITA BRUTA" color="#6ee7a0" />
          <KPI val="85" label="PEDIDOS PERDIDOS" color="#fdba74" />
        </View>
      </View>

      {/* MENU */}
      <View style={styles.menuWrap}>
        <Text style={styles.menuTitle}>Navegue pela proposta</Text>
        {MENU.map((item) => (
          <TouchableOpacity
            key={item.route}
            style={styles.menuCard}
            onPress={() => router.push(item.route as any)}
            activeOpacity={0.75}
          >
            <View style={styles.menuLeft}>
              <Text style={styles.menuLabel}>{item.label}</Text>
              <Text style={styles.menuDesc}>{item.desc}</Text>
            </View>
            <Text style={styles.menuArrow}>›</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* CTA BOTTOM */}
      <View style={styles.ctaWrap}>
        <TouchableOpacity
          style={styles.btnWhatsApp}
          onPress={() => Linking.openURL('https://wa.me/5511986661784')}
        >
          <Text style={styles.btnWhatsAppText}>📱 WhatsApp — Fechar agora</Text>
        </TouchableOpacity>
        <Text style={styles.ctaPhone}>(11) 98666-1784 · (11) 96425-1461</Text>
        <Text style={styles.ctaAddress}>Av. Diogo Antônio Feijó, 855 – KM18, Osasco/SP</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.dark },

  /* HERO */
  hero: {
    backgroundColor: Colors.dark,
    paddingHorizontal: 24,
    paddingTop: 64,
    paddingBottom: 40,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(234,29,44,.15)',
    borderWidth: 1,
    borderColor: 'rgba(234,29,44,.3)',
    borderRadius: 99,
    paddingHorizontal: 12,
    paddingVertical: 5,
    alignSelf: 'flex-start',
    marginBottom: 20,
  },
  badgeDot: {
    width: 5,
    height: 5,
    borderRadius: 99,
    backgroundColor: Colors.red,
  },
  badgeText: {
    color: '#ff8080',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.5,
  },
  heroTitle: {
    fontSize: 38,
    fontWeight: '900',
    color: '#fff',
    lineHeight: 42,
    marginBottom: 14,
  },
  heroTitleRed: { color: Colors.red },
  heroSub: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.5)',
    lineHeight: 22,
    marginBottom: 32,
  },

  /* KPI GRID */
  kpiGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.07)',
  },
  kpiBox: {
    width: '50%',
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 16,
    borderWidth: 0.5,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  kpiVal: {
    fontFamily: 'monospace',
    fontSize: 22,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 4,
  },
  kpiLabel: {
    fontSize: 9,
    color: 'rgba(255,255,255,0.3)',
    fontWeight: '700',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },

  /* MENU */
  menuWrap: {
    backgroundColor: Colors.bg,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 24,
    paddingBottom: 0,
    marginTop: -4,
  },
  menuTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: Colors.t3,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 14,
  },
  menuCard: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.s3,
    padding: 16,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 4,
    elevation: 2,
  },
  menuLeft: { flex: 1 },
  menuLabel: { fontSize: 14, fontWeight: '700', color: Colors.txt, marginBottom: 2 },
  menuDesc: { fontSize: 12, color: Colors.t2 },
  menuArrow: { fontSize: 22, color: Colors.t3, marginLeft: 8 },

  /* CTA */
  ctaWrap: {
    backgroundColor: Colors.bg,
    padding: 24,
    alignItems: 'center',
  },
  btnWhatsApp: {
    backgroundColor: Colors.red,
    borderRadius: 99,
    paddingVertical: 14,
    paddingHorizontal: 32,
    width: '100%',
    alignItems: 'center',
    marginBottom: 14,
  },
  btnWhatsAppText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  ctaPhone: { fontSize: 12, color: Colors.t2, marginBottom: 4 },
  ctaAddress: { fontSize: 11, color: Colors.t3, textAlign: 'center' },
});
