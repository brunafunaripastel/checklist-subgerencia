import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import ScreenHeader from '../components/ScreenHeader';
import { Colors } from '../constants/Colors';

const STEPS = [
  {
    num: '1',
    title: 'Assinatura via DocuSign',
    desc: 'Proposta assinada eletronicamente. Validade jurídica plena conforme MP 2.200-2/2001.',
    time: 'Dia 1',
  },
  {
    num: '2',
    title: 'Integração técnica',
    desc: 'Setup no Foody Delivery, acesso às plataformas (iFood, 99Food, Cardápio Web). Via WhatsApp + AnyDesk.',
    time: 'Dia 1–2',
  },
  {
    num: '3',
    title: 'Onboarding da equipe',
    desc: 'Briefing dos entregadores com identidade e padrão do Fratelli. Fardamento e apresentação adequados.',
    time: 'Dia 2–3',
  },
  {
    num: '4',
    title: 'Operação plena',
    desc: 'Acompanhamento diário nas primeiras 2 semanas. Relatório semanal toda segunda-feira.',
    time: 'Dia 4+',
  },
];

export default function ProximosPassosScreen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.bg }} showsVerticalScrollIndicator={false}>
      <ScreenHeader
        tag="Como começa"
        title="Da assinatura à"
        titleEm="primeira entrega."
        sub="4 passos simples para colocar a operação em marcha."
      />

      {STEPS.map((step, i) => (
        <View key={i} style={styles.stepWrap}>
          <View style={styles.stepLeft}>
            <View style={styles.stepNum}>
              <Text style={styles.stepNumText}>{step.num}</Text>
            </View>
            {i < STEPS.length - 1 && <View style={styles.stepLine} />}
          </View>
          <View style={styles.stepCard}>
            <View style={styles.stepHeader}>
              <Text style={styles.stepTitle}>{step.title}</Text>
              <View style={styles.stepTimeBadge}>
                <Text style={styles.stepTime}>{step.time}</Text>
              </View>
            </View>
            <Text style={styles.stepDesc}>{step.desc}</Text>
          </View>
        </View>
      ))}

      {/* CTA */}
      <View style={styles.ctaCard}>
        <Text style={styles.ctaTitle}>Pronto para reduzir{'\n'}esses 17,9%?</Text>
        <Text style={styles.ctaSub}>85 pedidos cancelados no último mês. A solução está a uma assinatura de distância.</Text>
        <TouchableOpacity
          style={styles.btnWa}
          onPress={() => Linking.openURL('https://wa.me/5511986661784')}
        >
          <Text style={styles.btnWaText}>📱 WhatsApp agora</Text>
        </TouchableOpacity>
        <View style={styles.contacts}>
          <Text style={styles.contactItem}>📧 reinaldo@osascoexpress.com.br</Text>
          <Text style={styles.contactItem}>📞 (11) 98666-1784</Text>
          <Text style={styles.contactItem}>📞 (11) 96425-1461</Text>
          <Text style={styles.contactItem}>📍 Av. Diogo Antônio Feijó, 855 – KM18, Osasco/SP</Text>
        </View>
      </View>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  stepWrap: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 0,
  },
  stepLeft: { alignItems: 'center', marginRight: 14 },
  stepNum: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.red,
    alignItems: 'center', justifyContent: 'center',
    zIndex: 1,
  },
  stepNumText: { fontFamily: 'monospace', fontSize: 13, fontWeight: '600', color: '#fff' },
  stepLine: {
    width: 2,
    flex: 1,
    backgroundColor: Colors.s3,
    marginVertical: 4,
    minHeight: 16,
  },
  stepCard: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: Colors.s3,
    padding: 16,
    marginBottom: 12,
  },
  stepHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  stepTitle: { fontSize: 13, fontWeight: '800', color: Colors.txt, flex: 1 },
  stepTimeBadge: {
    backgroundColor: Colors.s1,
    borderRadius: 99,
    paddingHorizontal: 8,
    paddingVertical: 3,
    marginLeft: 8,
  },
  stepTime: { fontSize: 10, fontWeight: '600', color: Colors.t2 },
  stepDesc: { fontSize: 12, color: Colors.t2, lineHeight: 17 },

  ctaCard: {
    backgroundColor: Colors.dark,
    borderRadius: 16,
    margin: 20,
    padding: 28,
    alignItems: 'center',
  },
  ctaTitle: { fontSize: 24, fontWeight: '900', color: '#fff', textAlign: 'center', marginBottom: 10 },
  ctaSub: { fontSize: 13, color: 'rgba(255,255,255,0.4)', textAlign: 'center', lineHeight: 20, marginBottom: 24 },
  btnWa: {
    backgroundColor: Colors.red,
    borderRadius: 99,
    paddingVertical: 14,
    paddingHorizontal: 32,
    width: '100%',
    alignItems: 'center',
    marginBottom: 20,
  },
  btnWaText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  contacts: { gap: 6, width: '100%' },
  contactItem: { fontSize: 11, color: 'rgba(255,255,255,0.35)', textAlign: 'center' },
});
