import { View, Text, StyleSheet, ScrollView } from 'react-native';
import ScreenHeader from '../components/ScreenHeader';
import { Colors } from '../constants/Colors';

const CLAUSES = [
  {
    num: '§1',
    title: 'Vigência mínima de 90 dias.',
    text: 'Rescisão antecipada pela contratante implica multa de 30% da média mensal faturada, pagável em 5 dias úteis.',
  },
  {
    num: '§2',
    title: 'Pagamento semanal via PIX,',
    text: 'toda segunda-feira. Relatório enviado pela manhã. Atraso implica multa de 2% + juros de 1%/mês + IGP-M.',
  },
  {
    num: '§3',
    title: 'Cancelamento após deslocamento',
    text: 'do entregador é cobrado integralmente. Atraso de retirada >10min: R$2,50/pedido a cada 10min.',
  },
  {
    num: '§4',
    title: 'Entrega não finalizada:',
    text: 'entregador aguarda 10 min com foto do pedido. Entrega considerada concluída e valor integral devido.',
  },
  {
    num: '§5',
    title: 'Alimentação (janta)',
    text: 'dos entregadores em serviço por conta da contratante — somente o alimento, sem embalagens.',
  },
  {
    num: '§6',
    title: 'Entregadores parceiros MEI',
    text: 'sem vínculo empregatício. A contratada atua como intermediadora logística e tecnológica.',
  },
];

export default function ContratoScreen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.bg }} showsVerticalScrollIndicator={false}>
      <ScreenHeader
        tag="Contrato comercial"
        title="Termos claros e"
        titleEm="sem pegadinhas."
      />

      {/* Partes */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Identificação das partes</Text>
        <View style={styles.partiesRow}>
          <View style={styles.partyCard}>
            <Text style={styles.partyRole}>CONTRATANTE</Text>
            <Text style={styles.partyName}>Fratelli Espaço Gourmet Ltda</Text>
            <Text style={styles.partyDetail}>CNPJ: 42.212.888/0003-38</Text>
            <Text style={styles.partyDetail}>Representante: Henrique</Text>
          </View>
          <View style={styles.partyCard}>
            <Text style={styles.partyRole}>CONTRATADA</Text>
            <Text style={styles.partyName}>Osasco Express Serviços Ltda – ME</Text>
            <Text style={styles.partyDetail}>CNPJ: 54.707.097/0001-04</Text>
            <Text style={styles.partyDetail}>Rep.: Reinaldo Alves de Souza Junior</Text>
          </View>
        </View>
      </View>

      {/* Cláusulas */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Condições principais</Text>
        {CLAUSES.map((c, i) => (
          <View key={i} style={styles.clause}>
            <View style={styles.clauseNum}>
              <Text style={styles.clauseNumText}>{c.num}</Text>
            </View>
            <View style={styles.clauseBody}>
              <Text style={styles.clauseTitle}>{c.title} </Text>
              <Text style={styles.clauseText}>{c.text}</Text>
            </View>
          </View>
        ))}
      </View>

      {/* Assinaturas */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Assinatura — Osasco/SP</Text>
        <View style={styles.sigRow}>
          <View style={styles.sigBox}>
            <Text style={styles.sigLabel}>Assinatura eletrônica via DocuSign</Text>
            <View style={styles.sigLine} />
            <Text style={styles.sigName}>Fratelli Espaço Gourmet Ltda</Text>
            <Text style={styles.sigPerson}>Representante: Henrique</Text>
          </View>
          <View style={styles.sigBox}>
            <Text style={styles.sigLabel}>Assinatura eletrônica via DocuSign</Text>
            <View style={styles.sigLine} />
            <Text style={styles.sigName}>Osasco Express Serviços Ltda – ME</Text>
            <Text style={styles.sigPerson}>Rep.: Reinaldo Alves de Souza Junior</Text>
          </View>
        </View>
      </View>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  section: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.s3,
    padding: 20,
    marginHorizontal: 20,
    marginBottom: 14,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: Colors.txt,
    marginBottom: 14,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.s2,
  },
  partiesRow: { flexDirection: 'row', gap: 12 },
  partyCard: { flex: 1 },
  partyRole: { fontSize: 9, fontWeight: '700', letterSpacing: 1.2, textTransform: 'uppercase', color: Colors.t3, marginBottom: 6 },
  partyName: { fontSize: 13, fontWeight: '800', color: Colors.txt, marginBottom: 4 },
  partyDetail: { fontSize: 11, color: Colors.t2, lineHeight: 17 },

  clause: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  clauseNum: {
    width: 32, height: 32, borderRadius: 8,
    backgroundColor: Colors.redBg,
    borderWidth: 1, borderColor: Colors.redBorder,
    alignItems: 'center', justifyContent: 'center',
    flexShrink: 0,
  },
  clauseNumText: { fontSize: 10, fontWeight: '700', color: Colors.red },
  clauseBody: { flex: 1 },
  clauseTitle: { fontSize: 12, fontWeight: '800', color: Colors.txt },
  clauseText: { fontSize: 12, color: Colors.t2, lineHeight: 18 },

  sigRow: { flexDirection: 'row', gap: 12 },
  sigBox: {
    flex: 1,
    backgroundColor: Colors.s1,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.t4,
    borderStyle: 'dashed',
    padding: 14,
    alignItems: 'center',
  },
  sigLabel: { fontSize: 10, color: Colors.t3, marginBottom: 24, textAlign: 'center' },
  sigLine: { width: '100%', height: 1, backgroundColor: Colors.txt, marginBottom: 8 },
  sigName: { fontSize: 11, fontWeight: '600', color: Colors.txt, textAlign: 'center' },
  sigPerson: { fontSize: 10, color: Colors.t2, textAlign: 'center' },
});
