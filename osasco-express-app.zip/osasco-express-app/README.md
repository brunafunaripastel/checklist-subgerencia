# 📱 Osasco Express — App Proposta Comercial

App mobile (iOS + Android) da proposta comercial Osasco Express × Fratelli.
Construído com **React Native + Expo Router**.

---

## 🚀 Como rodar localmente

### 1. Instale as dependências
```bash
npm install
```

### 2. Inicie o app
```bash
npm start
```

Isso abre o **Expo Dev Server**. Você vai ver um QR Code no terminal.

### 3. Teste no celular
- Baixe o app **Expo Go** no iPhone ou Android
- Escaneie o QR Code
- O app abre instantaneamente ✅

---

## 📦 Como gerar o APK / IPA (build real)

### Instale o EAS CLI
```bash
npm install -g eas-cli
eas login
```

### Configure o projeto
```bash
eas build:configure
```

### Build para Android (APK)
```bash
eas build --platform android --profile preview
```

### Build para iOS (IPA)
```bash
eas build --platform ios
```

> **Nota iOS:** Precisa de conta Apple Developer ($99/ano) para publicar na App Store.
> Para Android, o APK gerado já pode ser instalado diretamente.

---

## 🏗️ Estrutura do projeto

```
osasco-express-app/
├── app/
│   ├── _layout.tsx          # Layout raiz (navegação)
│   ├── index.tsx            # Tela inicial (Hero + menu)
│   ├── dashboard.tsx        # Dashboard com dados reais
│   ├── servicos.tsx         # Serviços oferecidos
│   ├── roi.tsx              # Retorno do investimento
│   ├── precos.tsx           # Tabela de valores
│   ├── escala.tsx           # Escala operacional
│   ├── contrato.tsx         # Contrato e cláusulas
│   └── proximos-passos.tsx  # Como começar
├── components/
│   └── ScreenHeader.tsx     # Header reutilizável
├── constants/
│   └── Colors.ts            # Paleta de cores
├── app.json                 # Configuração Expo
└── package.json
```

---

## 🔗 Subir no GitHub

```bash
git init
git add .
git commit -m "feat: app proposta Osasco Express"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/osasco-express-app.git
git push -u origin main
```

---

## 📋 Telas

| Tela | Conteúdo |
|------|----------|
| **Home** | KPIs gerais, menu de navegação, WhatsApp |
| **Dashboard** | Gráficos: pedidos por hora, dia, status, pagamento |
| **Serviços** | 6 pilares + comparativo dor vs solução |
| **ROI** | Cálculo financeiro: perda atual vs investimento |
| **Preços** | Tabela por km (seg-qui / sex-dom) + adicionais |
| **Escala** | Equipe dias úteis vs final de semana |
| **Contrato** | Partes, 6 cláusulas, área de assinatura |
| **Próximos Passos** | Timeline 4 etapas + CTA final |

---

## 🛠️ Tecnologias

- **Expo SDK 52** — build iOS + Android sem Xcode/Android Studio
- **Expo Router** — navegação por arquivos (igual Next.js)
- **React Native** — componentes nativos
- **TypeScript** — tipagem

---

## 📞 Contato

**Reinaldo Alves de Souza Junior**  
📱 (11) 98666-1784  
📱 (11) 96425-1461  
📍 Av. Diogo Antônio Feijó, 855 – KM18, Osasco/SP
